package me.ibrahimsn.lib

interface OnItemLongClickListener {
    fun onItemLongClick(pos: Int)
}